import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class heatmap extends StatefulWidget {
  @override
  _bluetoothState createState() => _bluetoothState();
}

class _bluetoothState extends State<heatmap> {
  GoogleMapController mapController;

  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.amber,

      appBar: AppBar(
        title: Text('Heat Map',
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
              fontSize: 28.0,
            )),
        centerTitle: true,
        backgroundColor: Colors.amberAccent,
      ),
      body: Stack(

          children: [

            GoogleMap(

              initialCameraPosition: CameraPosition(
                  target: LatLng(23.8103, 90.4125), zoom: 10),

              onMapCreated: _onMapCreated,
              // markers: Set.from(allMarkers),
              myLocationEnabled: true,
              // Add little blue dot for device location, requires permission from user
              mapType: MapType.normal,
              //trackCameraPosition: true
            ),

          ]
      ),
    );
  }

  _onMapCreated(GoogleMapController controller) {
    setState(() async {
      mapController = controller;
    });
  }
}