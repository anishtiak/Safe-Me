import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:safeme/dialogs.dart';
import 'package:safeme/heatmap.dart';
import 'package:safeme/info.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:safeme/user_preferences.dart';
import 'package:sms/sms.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:splashscreen/splashscreen.dart';
//import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'db_helper.dart';
import 'employee.dart';


var db = new DBHelper();
//Future<List> _users = db.getAllRecords("Employee"); // CALLS FUTURE




void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await UserPreferences().init();
  runApp(
      MaterialApp(
          debugShowCheckedModeBanner: false,


          home:SafeMe()
      ));
}




class SafeMe extends StatefulWidget {


  @override

  _SafeMeState createState() => _SafeMeState();
}



class _SafeMeState extends State<SafeMe> {
  //List<Employee> employees=[];


  TextEditingController controller = TextEditingController();
  String name;
  int curUserId;


  String data;



  @override
  void initState() {
    data = UserPreferences().data;


    super.initState();


  }



  Future<Null> sendSms()async {
    print("SendSMS");
    SmsSender sender = new SmsSender();
    String address = "+88$data";



    SmsMessage message = new SmsMessage(address, locationmsg);
    sender.sendSms(message);
    message.onStateChanged.listen((state) {
      if (state == SmsMessageState.Sent) {
        Dialogs.confirmation(context, 'SMS sent', 'SMS is delivered to trusted contact ${address}');
        print("SMS is sent!");
      } else if (state == SmsMessageState.Delivered) {

        Dialogs.confirmation(context, 'SMS sent', 'SMS is delivered to trusted contact ${address}');


        print("SMS is delivered!");
      }
    });


  }



  String locationmsg="";
  void getlocation()async{
    final position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    print(position);

    setState(() {
      locationmsg = "I need help. i am at\n https://www.google.com/search?q=${position.latitude},${position.longitude}";
    });
  }

  //String name ="";
  String number ="";

  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.black,

      appBar: AppBar(
        title:Text('Safe Me',
            style:TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
              fontSize: 28.0,
            )),
        centerTitle: true,
        backgroundColor: Colors.amberAccent,

        elevation: 0.0,

      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background3.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[

                Text(
                    'Name',
                    style:TextStyle(
                      color: Colors.white,
                      letterSpacing: 2.0,
                      fontSize: 28.0,
                      fontWeight: FontWeight.bold,

                    )
                ),
                SizedBox(height: 5.0,),
                Container(

                  child: TextField(
                    //autofocus: true,
                    cursorColor: Colors.white,
                    style: TextStyle(height: 2.0),
                    cursorWidth: 5.0,

                    decoration: InputDecoration(

                      hintText:'',
                      border: InputBorder.none,
                      fillColor: Colors.amberAccent,
                      filled: true,

                    ),
                      onChanged: (String c){
                        name =c;
                       //UserPreferences().data = name;
                       // setState(() {
                        // data = UserPreferences().data;
                       // });

                      }

                  ),
                ),


                SizedBox(height: 10.0,),
                Text(
                    'Trusted Contact : ',
                    style:TextStyle(
                      color: Colors.white,
                      letterSpacing: 2.0,
                      fontSize: 28.0,
                      fontWeight: FontWeight.bold,

                    )
                ),
                SizedBox(height: 5.0,),
                Container(

                  child: TextField(
                      keyboardType: TextInputType.number,


                      maxLength: 11,
                      //autofocus: true,
                      cursorColor: Colors.white,
                      style: TextStyle(height: 2.0),
                      cursorWidth: 5.0,


                      decoration: InputDecoration(
                        hintText: data ?? '',
                        border: InputBorder.none,
                        fillColor: Colors.amberAccent,

                        filled: true,

                      ),
                      onChanged: (String b){
                        number=b;
                        UserPreferences().data = number;
                        setState(() {
                          data = UserPreferences().data;
                        });


                      }

                  ),
                ),


                SizedBox(height: 5.0,),



                Row(
                  children: <Widget>[
                    FlatButton(
                      onPressed: (){     Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => DBTestPage()),
                      );
                      },
                      color: Colors.amberAccent[200],
                      child: Text('Edit information',
                          style:TextStyle(

                            letterSpacing: 1.0,
                            fontWeight: FontWeight.bold,
                          )),
                    ),

                  ],
                ),
                SizedBox(height: 20.0,),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[

                    SizedBox(height: 5.0,),
                    FlatButton(

                      onPressed: () async {
                        await Firebase.initializeApp();

                        Navigator.push(
                          context,

                          MaterialPageRoute(builder: (context) => heatmap()),
                        );

                      },
                      color: Colors.amberAccent,
                      child: Text('Red Flag Areas',
                          style:TextStyle(
                            fontSize: 20.0,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    SizedBox(height: 5.0,),

                    FlatButton(

                      onPressed: () async {

                        final action = await Dialogs.yesAbortDialog(context, 'Are you sure ?', 'This will send your location to you trusted contacts');
                        if (action==DialogeAction.yes){
                          await getlocation();
                          sendSms();
                          Position position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                          print("${position.latitude} and ${position.longitude}");

                          await Firebase.initializeApp();
                          FirebaseFirestore.instance.collection('markers').add({
                            'coords':new GeoPoint(position.latitude, position.longitude)
                          });
                        }

                        if (action==DialogeAction.abort){

                        }

                      },
                      color: Colors.redAccent,
                      child: Text('DISTRESS',
                          style:TextStyle(
                            fontSize: 25.0,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    SizedBox(height: 5.0,),
                    FlatButton(
                      padding: EdgeInsets.all(10.0),

                      onPressed: (){},
                      color: Colors.amberAccent,
                      child: Text(locationmsg,
                          style:TextStyle(
                            fontSize: 20.0,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    SizedBox(height: 5.0,),


                  ],

                ),

              ],
            ),



          ),
        ),
      ),


    );

  }


}
