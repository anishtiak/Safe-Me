
import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

enum DialogeAction{ yes, abort}

class Dialogs{
  static Future<DialogeAction> yesAbortDialog(BuildContext context,
      String title, String body,)
  async{

    final action = await showDialog(

      context: context,
      barrierDismissible:false,
      builder:(BuildContext context){



      //  Timer(Duration(seconds: 3), () {
       //   print("Yeah, this line is printed after 3 seconds");

       //     Navigator.of(context).pop(DialogeAction.yes);
      // }
      // );


        //@Override
        return AlertDialog(


            backgroundColor: Colors.amber[100],

            title: Text(title),

            content: Text(body),
            actions: <Widget>[




            FlatButton(
              color: Colors.amberAccent,



              shape: RoundedRectangleBorder(side: BorderSide(color: Colors.white)),
              onPressed: ()=>Navigator.of(context).pop(DialogeAction.yes),
              child: const Text('YES',style: TextStyle(color: Colors.white,fontSize: 25.0, fontWeight: FontWeight.bold,),
              ),
        ),
              RaisedButton(
                color: Colors.amberAccent,
                shape: RoundedRectangleBorder(side: BorderSide(color: Colors.white)),
                onPressed: ()=>Navigator.of(context).pop(DialogeAction.abort),
                child: const Text('NO',style: TextStyle(color: Colors.white,fontSize: 25.0, fontWeight: FontWeight.bold,),

              ),
              ),


      ]


        );




      }


    );
    return (action!=null) ? action : DialogeAction.yes;

  }

  static  confirmation(BuildContext context,
      String title, String body,)
  async{
    await showDialog(

        context: context,
        barrierDismissible:false,
        builder:(BuildContext context){



        Timer(Duration(seconds: 3), () {
         print("Yeah, this line is printed after 3 seconds");

           Navigator.of(context).pop();
       }
       );


      //@Override
      return AlertDialog(


          backgroundColor: Colors.amber[100],

          title: Text(title),

    content: Text(body),

      );


        }


    );

  }

}